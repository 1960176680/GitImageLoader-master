package imageloader.listener;

/**
 * Created by zy on 16-6-10.
 */
public class DefaultListener implements Listener {
    @Override
    public void loadStarted() {

    }

    @Override
    public void loadFinished() {

    }
}
