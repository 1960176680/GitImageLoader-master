package imageloader.listener;

/**
 * Created by zy on 16-5-26.
 */
public interface Listener {
    void loadStarted();
    void loadFinished();
}
