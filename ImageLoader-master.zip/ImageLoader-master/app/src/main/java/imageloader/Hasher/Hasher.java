package imageloader.Hasher;

/**
 * Created by zy on 16-6-11.
 */
public interface Hasher {
    String hash(String url);
}
