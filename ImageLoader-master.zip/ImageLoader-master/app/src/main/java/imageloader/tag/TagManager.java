package imageloader.tag;

import android.view.View;

/**
 * Created by zy on 16-6-11.
 */
public class TagManager {

    public void setTag(Object tag, View view) {
        view.setTag(tag);
    }

}
