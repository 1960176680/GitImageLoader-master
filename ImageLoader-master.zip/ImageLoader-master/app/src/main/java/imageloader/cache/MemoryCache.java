package imageloader.cache;

/**
 * Created by zy on 16-6-24.
 */
public abstract class MemoryCache implements LoadCache{
}
