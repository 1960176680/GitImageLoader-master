package imageloader.cache;

import android.content.Context;

import imageloader.DisplayTask;

/**
 * Created by zy on 16-6-24.
 */
public abstract class DiskCache implements LoadCache{

    public DiskCache() {

    }
}
